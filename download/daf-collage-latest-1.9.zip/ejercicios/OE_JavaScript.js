
function tipoOrden(){
    var seleccion = parseInt(document.getElementById("opcionOrden").value);//variable para saber distancia entre los huecos [N]
    console.log(seleccion);
//    $("#divPregunta1").append('<textarea rows="4" cols="50"> Introduzca el texto </textarea>');

}
